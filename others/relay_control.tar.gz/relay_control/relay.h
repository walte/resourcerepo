
#ifndef __RELAY_H
#define __RELAY_H

#define MAXARG 20
#define MAXLINE 200
#define MAXCHANNEL 16

/* commands */
#define RELAY_SINGLE_ON 0x01
#define RELAY_SINGLE_OFF 0x02
#define RELAY_ALL_ON 0x03
#define RELAY_ALL_OFF 0x04
#define RELAY_SEVERAL_ON 0x05
#define RELAY_SEVERAL_OFF 0x06
#define RELAY_STATE_READ 0x07

/* byte offset */
#define RELAY_STYLE_OFFS 2
#define RELAY_ADDR_OFFS 3
#define RELAY_COMMAND_OFFS 4
#define RELAY_DATA0_OFFS 5
#define RELAY_DATA1_OFFS 6
#define RELAY_DATA2_OFFS 7
#define RELAY_STATE0_OFFS 6
#define RELAY_STATE1_OFFS 7
#define RELAY_SUM_OFFS 8

/* initial data */
#define RELAY_STYLE_INIT 0x55
#define RELAY_ADDR_INIT 0x00

/* buffer lenth */
#define RELAY_READ_LEN 9
#define RELAY_WRITE_LEN 9

/* relay_info */
struct relay_info {
	int fd;
	unsigned char write_buff[RELAY_READ_LEN];
	unsigned char read_buff[RELAY_WRITE_LEN];
	struct list_head head;
};

/* thread_info */
struct thread_info{
	pthread_t pid;
	char name[MAXARG];
	int counter;
	int thread_state;
};

/* relay_command */
struct relay_command{
	char command_code;
	int data;
	int sleep;
	struct list_head list;
};

/* relay_command_list */
struct relay_command_list{
	char command_str[MAXLINE];
	struct relay_command command_head;
	struct list_head list;
	struct thread_info pthread;
	struct relay_info *relay;
};

#endif

