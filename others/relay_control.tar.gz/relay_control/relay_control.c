
#include <pthread.h>
#include <string.h>
#include <poll.h>

#include "termios.h"
#include "list.h"
#include "relay.h"

#define RELAY_DEV_INIT  "/dev/ttyS0"

#define RELAY_RETRY 5

//#define DEBUG
//#define DEBUG_CMD_BUFF

//#define VERIFY_READING

#ifdef DEBUG
#define D_PRINTF(fmt, arg...) printf("LOG[%s:%d] "fmt, __func__, __LINE__, ##arg);
#else
#define D_PRINTF(...)
#endif

static char command[MAXLINE];
static char command_cache[MAXLINE];

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;

unsigned char relay_cacl_sum(unsigned char *src_data, int len)
{
	int cnt;
	unsigned char val = 0;

	for (cnt = 0; cnt < len; cnt++)
		val += src_data[cnt];
	
	return val;
}

int relay_check_sum(unsigned char *src_data, unsigned char *sum, int num)
{
	int cnt;
	unsigned char tmp_sum = 0;

	for(cnt = 0; cnt < num; cnt++)
		tmp_sum += *(src_data + cnt);

	if (tmp_sum != *sum)
		return -1;
	else
		return 0;
}

void relay_write_buff_init(unsigned char *buff)
{
	*buff = 0x00;
	*(buff+1) = 0x5A;
	*(buff+2) = RELAY_STYLE_INIT;
	*(buff+3) = RELAY_ADDR_INIT;
}

void thread_cleanup(void *arg)
{
	pthread_mutex_unlock((pthread_mutex_t *)arg);
}

static int relay_send_command(struct relay_info *relay, int command, int channels, int retry)
{
	int ret;
	int cnt;
	int retr = -1;
	unsigned char *w_buff = relay->write_buff;
	unsigned char *r_buff = relay->read_buff;
	struct pollfd fdinfo[1];

	fdinfo[0].fd = relay->fd;
	fdinfo[0].events = POLLIN | POLLPRI;

	while(retry--){
		pthread_cleanup_push(thread_cleanup, (void *)&mtx);
		pthread_mutex_lock(&mtx);
		*(w_buff + RELAY_COMMAND_OFFS) = command;
		*(w_buff + RELAY_DATA0_OFFS) = (channels & 0xFF);
		*(w_buff + RELAY_DATA1_OFFS) = ((channels >> 8) & 0xFF);
		*(w_buff + RELAY_DATA2_OFFS) = 0x00;
		*(w_buff + RELAY_SUM_OFFS) = relay_cacl_sum(w_buff, 8);
#ifdef DEBUG_CMD_BUFF
		printf("write buff: ");
		for (cnt = 0; cnt < RELAY_WRITE_LEN; cnt++)
			printf("0x%02x ", *(w_buff + cnt));
		printf("\n");
#endif
		ret = write(relay->fd, w_buff, RELAY_WRITE_LEN);
		if (ret != RELAY_WRITE_LEN) {
			printf("error!!! write num %d\n", ret);
			goto next;
		}

#ifdef VERIFY_READING
		if (poll(fdinfo, 1, 50)  == -1) {
			printf("poll timeout!!!\n");
			goto next;
		}

		if (fdinfo[0].revents & (POLLIN | POLLPRI)) {
			usleep(10*1000);
			ret = read(relay->fd, r_buff, RELAY_READ_LEN);
		} else {
			printf("cannot read!!!\n");
			goto next;
		}

		if (ret != RELAY_READ_LEN) {
			printf("error! read num %d\n", ret);
			goto next;
		}
#ifdef DEBUG_CMD_BUFF
		printf("read buff: ");
		for (cnt =0; cnt < RELAY_WRITE_LEN; cnt++)
			printf("0x%02x ", *(r_buff + cnt));
		printf("\n");
#endif
		ret = relay_check_sum(r_buff, r_buff + RELAY_SUM_OFFS, 8);
#else
		usleep(50*1000);
		ret = 0;
#endif
		pthread_mutex_unlock(&mtx);

		if (!ret)
			retr = 0;
		else
			printf("error!!! relay_check_sum %d\n", ret);
next:
		pthread_mutex_unlock(&mtx);
		pthread_cleanup_pop(0);

		if(!retr)
			break;
		/* need repeat */
		usleep(50*1000);
	}

	return retr;
}

/* getargs */
static int getargs(int *argcp, char *argv[], int max)
{
	char *cmdp;
	int i;

	if (fgets(command, sizeof(command), stdin) == NULL) {
		if (ferror(stdin))
			return -1;
		return -1;
	}
	if (strchr(command, '\n') == NULL) {
		/* eat up rest of line */
		while (1) {
			switch (getchar()) {
			case '\n':
				break;
			case EOF:
				if (ferror(stdin))
					return -1;
			default:
				continue;
			}
			break;
		}
		printf("Line too long -- command ignored\n");
		return -1;
	}

	strcpy(command_cache, command);

	cmdp = command_cache;
	for (i = 0; i < max; i++) {
		if ((argv[i] = strtok(cmdp, " \t\n")) == NULL)
			break;
		cmdp = NULL; /* tell strtok to keep going */
	}
	if (i >= max) {
		printf("Too many args -- command ignored\n");
		return -1;
	}
	*argcp = i;

	return 0;
}

int cmd_start(int argc, char *argv[], struct relay_command_list *relay_cmd_list)
{
	int i;
	int cnt;
	int name_offset = 0;
	int single_channel = 0;
	int channel = 0;
	int sleep = 0;

	char *cmdp;
	struct relay_command *relay_cmd = NULL;

	if (argc < 2) {
		printf("error start command!!!\n");
		printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
		return -1;
	}

	if ((strstr(argv[1], "name") == NULL) ||
			((strstr(argv[1], "name") != NULL) && (argc < 4))) {
		printf("error start command!!!\n");
		printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
		return -1;
	}

	/* name */
	if (strstr(argv[1], "name") != NULL) {
		D_PRINTF("name string: %s\n", argv[2]);
		if (sizeof(argv[2]) > MAXARG) {
			printf("error start command!!! (name is too long)\n");
			printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
			return -1;
		}

		if ((strchr(argv[2], '=') != NULL) || (strchr(argv[2], '-') != NULL) ||
			(strchr(argv[2], ',') != NULL) || (strchr(argv[2], ';') != NULL)) {
			printf("error start command!!! (contain illegal char)\n");
			printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
			return -1;
		}

		/* copy name string */
		strcpy(relay_cmd_list->pthread.name, argv[2]);
		name_offset = 2;
	}

	for (cnt = name_offset + 1; cnt < argc; cnt++) {
		/* malloc relay_command */
		relay_cmd = malloc(sizeof(struct relay_command));
		if (relay_cmd == NULL) {
			perror("malloc failure, struct relay_command");
			return -1;
		}
		INIT_LIST_HEAD(&relay_cmd->list);	

		if ((strstr(argv[cnt], "on") == NULL) &&
				(strstr(argv[cnt], "off") == NULL) &&
				(strstr(argv[cnt], "sleep") == NULL)) {
			printf("error start command!!!\n");
			printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
			free(relay_cmd);
			return -1;
		}

		if ((strstr(argv[cnt], "on") == NULL) &&
				(strstr(argv[cnt], "off") == NULL)) {
			printf("error start command!!!\n");
			printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
			free(relay_cmd);
			return -1;
		}

		if ((strstr(argv[cnt], "on") != NULL) &&
				(strstr(argv[cnt], "off") != NULL)) {
			printf("error start command!!!\n");
			printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
			free(relay_cmd);
			return -1;
		}

		/* on */
		if ((cmdp = strstr(argv[cnt], "on")) != NULL) {

			i = 2; /* offset of "on" */
			if (*(cmdp + i) != '=') {
				printf("error start command!!!\n");
				printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
				free(relay_cmd);
				return -1;
			}
			i++;

			single_channel = 0;
			channel = 0;

			while (1) {
				if (!((*(cmdp + i) >= '0' &&
					       *(cmdp + i) <= '9') ||
				       	       *(cmdp + i) == ',')) {
					printf("error start command!!!\n");
					printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
					free(relay_cmd);
					return -1;
				}

				if (*(cmdp + i) >= '0' && *(cmdp + i) <= '9') {
					 single_channel = single_channel * 10 + *(cmdp + i) - '0';	
					 //printf("line %d, %d\n", __LINE__, single_channel);
				} 
				else if (*(cmdp + i) == ',') {
					channel |= (1 << single_channel);
					single_channel = 0;

					 //printf("line %d, %x\n", __LINE__, channel);
				}
				 
				i++;
				if ((*(cmdp + i) == ';') || (*(cmdp + i) == '\0')) {
					if (*(cmdp + i - 1) != ',')
						channel |= (1 << single_channel);
					if (channel >= (0x01 << MAXCHANNEL)) {
						printf("error start command!!! (channel > 15)\n");
						printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
						free(relay_cmd);
						return -1;
					}


					relay_cmd->data = channel;
					relay_cmd->command_code = RELAY_SEVERAL_ON;

					single_channel = 0;
					channel = 0;
					D_PRINTF("command: on, channle: 0x%x\n", relay_cmd->data);

					break;
			
				}
			}
		}
		else if ((cmdp = strstr(argv[cnt], "off")) != NULL) { /* off */

			i = 3; /* offset of "off" */
			if (*(cmdp + i) != '=') {
				printf("error start command!!!\n");
				printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
				free(relay_cmd);
				return -1;
			}
			i++;

			single_channel = 0;
			channel = 0;

			while (1) {
				if (!((*(cmdp + i) >= '0' &&
					       *(cmdp + i) <= '9') ||
				       	       *(cmdp + i) == ',')) {
					printf("error start command!!!\n");
					printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
					free(relay_cmd);
					return -1;
				}

				if (*(cmdp + i) >= '0' && *(cmdp + i) <= '9') {
					 single_channel = single_channel * 10 + *(cmdp + i) - '0';	
					 //printf("line %d, %d\n", __LINE__, single_channel);
				} 
				else if (*(cmdp + i) == ',') {
					channel |= (1 << single_channel);
					single_channel = 0;
					 //printf("line %d, %x\n", __LINE__, channel);
				}
				 
				i++;
				if ((*(cmdp + i) == ';') || (*(cmdp + i) == '\0')) {
					if (*(cmdp + i - 1) != ',')
						channel |= (1 << single_channel);

					if (channel >= (0x01 << MAXCHANNEL)) {
						printf("error start command!!! (channel > 15)\n");
						printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
						free(relay_cmd);
						return -1;
					}

					relay_cmd->data = channel;
					relay_cmd->command_code = RELAY_SEVERAL_OFF;

					single_channel = 0;
					channel = 0;
					D_PRINTF("command: off, channle: 0x%x \n", relay_cmd->data);
					
					break;
			
				}
			}
		}
		
		/* sleep */
		if ((cmdp = strstr(argv[cnt], "sleep")) != NULL) {

			i = 5; /* offset of "sleep" */
			if (*(cmdp + i) != '=') {
				printf("error start command!!!\n");
				printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
				free(relay_cmd);
				return -1;
			}
			i++;

			single_channel = 0;
			sleep = 0;

			while (1) {
				if (!(*(cmdp + i) >= '0' &&
					       *(cmdp + i) <= '9')) {
					printf("error start command!!!\n");
					printf("Example: start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
					free(relay_cmd);
					return -1;
				}

				if (*(cmdp + i) >= '0' && *(cmdp + i) <= '9') {
					 single_channel = single_channel * 10 + *(cmdp + i) - '0';	
					 //printf("line %d, %d\n", __LINE__, single_channel);
				} 
				 
				i++;
				if ((*(cmdp + i) == ';') || (*(cmdp + i) == '\0')) {
					sleep = single_channel;
					single_channel = 0;

					relay_cmd->sleep = sleep;
					D_PRINTF("sleep %d\n", relay_cmd->sleep);

					break;
			
				}
			}
		} else {
			D_PRINTF("no sleep\n");
			relay_cmd->sleep = -1;
		}	

		list_add_tail(&relay_cmd->list, &relay_cmd_list->command_head.list);
	}
	return 0;
}	

int cmd_kill(int argc, char *argv[], struct relay_info *relay)
{
	struct relay_command_list *relay_cmd_list = NULL;
	struct relay_command *relay_cmd = NULL;
	struct list_head *list_f = NULL;

	if (argc != 2) {
		printf("error kill command!!!\n");
		printf("Example: kill name\n");
		return -1;
	}
	list_for_each_entry(relay_cmd_list, &relay->head, list) {
		if (!strcmp(relay_cmd_list->pthread.name, argv[1])) {
			pthread_cancel(relay_cmd_list->pthread.pid);
			pthread_join(relay_cmd_list->pthread.pid, NULL);
			printf("pid name \"%s\" killed\n", 
					relay_cmd_list->pthread.name);
			list_f = &relay_cmd_list->list;
			break;
		}
	}

	if (list_f != NULL) {
		/* destroy memory */
		list_del(list_f);

		relay_cmd_list = container_of(list_f,
					struct relay_command_list, list);
		relay_cmd_list->command_head.data = 0;
		while (!list_empty(&relay_cmd_list->command_head.list)) {
			D_PRINTF("free relay_cmd\n");
			relay_cmd = list_first_entry(&relay_cmd_list->command_head.list,
					struct relay_command, list);
			list_del(&relay_cmd->list);
			relay_cmd_list->command_head.data |= relay_cmd->data;
			free(relay_cmd);
		}
	
		D_PRINTF("free relay_command_list\n");
		/* after killed, set channel to off */
		relay_send_command(relay, relay_cmd_list->command_head.command_code,
				relay_cmd_list->command_head.data, RELAY_RETRY);
		free(relay_cmd_list);
	}

	return 0;
}

void cmd_state(int argc, char *argv[], struct relay_info *relay)
{
	struct relay_command_list *relay_cmd_list = NULL;
	
	if (argc != 1) {
		printf("error state command!!!\n");
		printf("Example: state\n");
	}

	/* pid name counter command_string */
	printf("name\t\tcounter\t\tcommand_string\n");
	list_for_each_entry(relay_cmd_list, &relay->head, list) {
		printf("%s\t\t", relay_cmd_list->pthread.name);
		printf("%d\t\t", relay_cmd_list->pthread.counter);
		printf("%s", relay_cmd_list->command_str);
	}
}

void cmd_quit(int argc, char *argv[], struct relay_info *relay)
{
	struct relay_command_list *relay_cmd_list = NULL;
	struct relay_command *relay_cmd = NULL;
	struct list_head *list_f = NULL;

	if (argc != 1) {
		printf("error state command!!!\n");
		printf("Example: quit\n");
	}

	while (!list_empty(&relay->head)) {
		relay_cmd_list = list_first_entry(&relay->head,
				struct relay_command_list, list);

		pthread_cancel(relay_cmd_list->pthread.pid);
		pthread_join(relay_cmd_list->pthread.pid, NULL);
		printf("pid name \"%s\" killed\n",
				relay_cmd_list->pthread.name);

		/* destroy memory */
		list_del(&relay_cmd_list->list);

		relay_cmd_list->command_head.data = 0;
		while (!list_empty(&relay_cmd_list->command_head.list)) {
			D_PRINTF("free relay_cmd\n");
			relay_cmd = list_first_entry(&relay_cmd_list->command_head.list,
					struct relay_command, list);
			list_del(&relay_cmd->list);
			relay_cmd_list->command_head.data |= relay_cmd->data;
			free(relay_cmd);
		}

		D_PRINTF("free relay_command_list\n");
		/* after killed, set channel to off */
		relay_send_command(relay, relay_cmd_list->command_head.command_code,
				relay_cmd_list->command_head.data, RELAY_RETRY);
		free(relay_cmd_list);
	}
}

void cmd_help(void)
{
	printf("Support command\n");
	printf("start------start -name aaa on=1,2;sleep=1 off=1,2;sleep=2\n");
	printf("     (set on/off in channel 0 ~ 15, keep for sleep seconds)\n");
	printf("kill------kill name\n");
	printf("state\n");
	printf("quit\n");
}

void *relay_thread(void *arg)
{
	struct relay_command *relay_cmd = NULL;
	struct relay_command_list *relay_cmd_list = (struct relay_command_list *)arg;

	relay_cmd_list->pthread.counter = 0;	
	while (1) {
		D_PRINTF("main loop\n");
		list_for_each_entry(relay_cmd, &relay_cmd_list->command_head.list, list) {
			relay_send_command(relay_cmd_list->relay, relay_cmd->command_code,
					relay_cmd->data, RELAY_RETRY);
			pthread_testcancel();

			if (relay_cmd->sleep == -1)
				break;
			else if (relay_cmd->sleep)
				sleep(relay_cmd->sleep);

			pthread_testcancel();
			D_PRINTF("step loop, sleep %d\n", relay_cmd->sleep);
		}

		relay_cmd_list->pthread.counter++;	
		
		if (relay_cmd->sleep == -1) {
			break;
		}
	}

	printf("pid name \"%s\" exit\n", 
			relay_cmd_list->pthread.name);

	/* destroy memory */
	while (!list_empty(&relay_cmd_list->command_head.list)) {
		D_PRINTF("free relay_cmd\n");
		relay_cmd = list_first_entry(&relay_cmd_list->command_head.list,
				struct relay_command, list);
		list_del(&relay_cmd->list);
		free(relay_cmd);
	}

	D_PRINTF("free relay_cmd_list\n");
	list_del(&relay_cmd_list->list);
	free(relay_cmd_list);

	pthread_exit("exit");	
}

int main(int argc, char **argv){
	char dev[MAXARG];
	char *cmd_argv[MAXARG];
	int cmd_argc;
	int ret;

	struct relay_info *relay = NULL;
	struct relay_command_list *relay_cmd_list = NULL;
	struct relay_command *relay_cmd = NULL;

	relay = malloc(sizeof(struct relay_info));
	if (relay == NULL) {
		perror("malloc failure, struct relay_info");
		exit(EXIT_FAILURE);
	}
	INIT_LIST_HEAD(&relay->head);
	relay_write_buff_init(relay->write_buff);

	/* get device node */
	if ((argc > 2) || ((2 == argc) && (strstr(argv[1], "tty") == NULL))) {
		printf("command error!!!\n");
		printf("./relay_control [tty device node]\n");
		exit(EXIT_FAILURE);
	}

	if (1 == argc)
		strcpy(dev, RELAY_DEV_INIT);
	else
		strcpy(dev, argv[1]);

	printf("open device node: %s\n", dev);
	relay->fd = open(dev, O_RDWR | O_NOCTTY | O_NDELAY);
	if (-1 == relay->fd)	
	{ 			
		perror("Can't Open Serial Port");
		free(relay);
		return -1;		
	}
	set_speed(relay->fd, 9600);
	if (set_parity(relay->fd, 8, 1, 'N') == -1)  {
		printf("Set Parity Error\n");
		free(relay);
		exit (0);
	}

	/* get command */
	while (1) {
		printf("@ ");
		if (!(getargs(&cmd_argc, cmd_argv, MAXARG)) && cmd_argc > 0) {
			if (strcmp(cmd_argv[0], "start") == 0) {
				relay_cmd_list = malloc(sizeof(struct relay_command_list));
				if (relay_cmd_list == NULL) {
					perror("malloc failure, struct relay_command_list");
					continue;
				}
				INIT_LIST_HEAD(&relay_cmd_list->list);
				INIT_LIST_HEAD(&relay_cmd_list->command_head.list);
				strcpy(relay_cmd_list->command_str, command);
				relay_cmd_list->command_head.command_code = RELAY_SEVERAL_OFF;
				relay_cmd_list->command_head.data = 0;

				if(cmd_start(cmd_argc, cmd_argv, relay_cmd_list)){
					/* free relay_command */
					while (!list_empty(&relay_cmd_list->command_head.list)) {
						D_PRINTF("free relay_cmd\n");
						relay_cmd = list_first_entry(&relay_cmd_list->command_head.list,
							struct relay_command, list);
						list_del(&relay_cmd->list);
						free(relay_cmd);
					}
					/* free relay_command_list */
					D_PRINTF("free relay_cmd_list\n");
					free(relay_cmd_list);
					continue;
				}
				
				relay_cmd_list->relay = relay;
				list_add_tail(&relay_cmd_list->list, &relay->head);

				ret = pthread_create(&relay_cmd_list->pthread.pid, NULL, relay_thread, relay_cmd_list);
				if(ret != 0) {
					perror("Thread creation failed");
					exit(EXIT_FAILURE);
				}


			}
			else if (strcmp(cmd_argv[0], "state") == 0)
				cmd_state(cmd_argc, cmd_argv, relay);
			else if (strcmp(cmd_argv[0], "kill") == 0)
				cmd_kill(cmd_argc, cmd_argv, relay);
			else if (strcmp(cmd_argv[0], "quit") == 0) {
				cmd_quit(cmd_argc, cmd_argv, relay);
				break;
			} else
				cmd_help();
		}

	}

	close(relay->fd);
	free(relay);
	exit (0);
}

