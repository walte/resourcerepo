
export PATH=$PATH:/usr/local/arm/4.3.2/bin/
#export CROSS_COMPILE=arm-eabi-
#export ARCH=arm

