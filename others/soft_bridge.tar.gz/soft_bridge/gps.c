
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <pthread.h>
#include <string.h>
#include <poll.h>
#include <fcntl.h>
#include <signal.h>

#include "termios.h"

#define MODEM_DEV  "/dev/ttyNXP0"

#ifdef DEBUG
#define D_PRINTF(fmt, arg...) printf("LOG[%s:%d] "fmt, __func__, __LINE__, ##arg);
#else
#define D_PRINTF(...)
#endif

#define WRITE_LEN 128
#define READ_LEN 128

#define TIMEOUT 10

static pid_t fpid, cpid;
static int quit_flag = 0;

static void signal_handler(int signo)
{
	if (signo == SIGUSR1)
	{
		D_PRINTF("set quit flag\n");
		quit_flag = 1;
	}
}

int main(int argc, char **argv){
	int modem_fd;
	unsigned char r_buff[READ_LEN] = {0};
	unsigned char w_buff[WRITE_LEN] = {0};
	struct termios initialrsettings, newrsettings;

	tcgetattr(fileno(stdin), &initialrsettings);
	newrsettings = initialrsettings;
	newrsettings.c_lflag &= ~ECHO;

	if (tcsetattr(fileno(stdin), TCSAFLUSH, &newrsettings) != 0)
	{
		perror("Could not set attributes");
		return -1;
	}

	D_PRINTF("open modem device: %s\n", MODEM_DEV);
	modem_fd = open(MODEM_DEV, O_RDWR | O_NOCTTY | O_NDELAY);
	if (-1 == modem_fd)	
	{ 			
		perror("Can't Open Modem Serial Port");
		return -1;		
	}
	set_speed(modem_fd, 115200);
	if (set_parity(modem_fd, 8, 1, 'N') == -1)  {
		perror("Set modem_fd Parity Error");
		exit (0);
	}

	if( signal( SIGUSR1, signal_handler) == SIG_ERR  )
	{
		perror("Parent: Unable to create handler for SIGUSR1");
	}

	fpid = getpid();
	cpid = fork();

	if (0 == cpid) {
		/* child thread */
		/* read from modem and write to stdout */
		/* return AT command result */
		struct timeval timeout;
		fd_set readfd;
		int cnt;

		while (1) {
			if (quit_flag)
				break;

			memset(w_buff, 0, WRITE_LEN);
			timeout.tv_sec = TIMEOUT;
			timeout.tv_usec = 0;
			FD_ZERO(&readfd);
			FD_SET(modem_fd, &readfd);
			D_PRINTF("child select start\n");
			if (!(select(modem_fd + 1, &readfd, NULL, NULL, &timeout) > 0))
				continue;
			D_PRINTF("child select complete\n");
			if(FD_ISSET(modem_fd, &readfd))
			{
				cnt = read(modem_fd, w_buff, WRITE_LEN);
				write(fileno(stdout), w_buff, cnt);
				D_PRINTF("AT result: %d, %s", cnt, w_buff);
			}
		}
		kill(fpid, SIGUSR1);
		D_PRINTF("write thread exit\n");
		exit(0);
	} else {
		/* read from stdin and write to modem */
		/* send AT command */
		struct timeval timeout;
		fd_set readfd;
		int cnt;

		while (1) {
			if (quit_flag)
				break;

			memset(r_buff, 0, READ_LEN);
			timeout.tv_sec = TIMEOUT;
			timeout.tv_usec = 0;
			FD_ZERO(&readfd);
			FD_SET(fileno(stdin), &readfd);
			D_PRINTF("main select start\n");
			if (!(select(fileno(stdin) + 1, &readfd, NULL, NULL, &timeout) > 0))
				continue;
			D_PRINTF("main select complete\n");
			if(FD_ISSET(fileno(stdin), &readfd))
			{
				cnt = read(fileno(stdin), r_buff, WRITE_LEN);
				if (!strcmp(r_buff, "exit\n"))
					break;
				else {
					write(modem_fd, r_buff, cnt);
					D_PRINTF("AT command: %s", r_buff);
				}
			}

		}
		kill(cpid, SIGUSR1);
	}

	waitpid(cpid, NULL, 0);
	close(modem_fd);
	
	tcsetattr(fileno(stdin), TCSANOW, &initialrsettings);
	
	return 0;
}

