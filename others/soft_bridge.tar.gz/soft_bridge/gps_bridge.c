
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <termios.h>

//#define DEVICE_TTYS "/dev/ttyNXP"
#define DEVICE_TTYS "/dev/ttymxc3"

#ifdef DEBUG
#define D_PRINTF(fmt, arg...) printf("LOG[%s:%d] "fmt, __func__, __LINE__, ##arg);
#else
#define D_PRINTF(...)
#endif

static char gfd_buf[2048] = {0};
static char infd_buf[128] = {0};

int main(int argc, char** argv)
{
	int cnt;
	int gps_fd;
	fd_set infds;
	struct timeval infd_tv;
	struct termios tio;
	struct termios initialrsettings, newrsettings;

	/* donot echo when type */
	tcgetattr(fileno(stdin), &initialrsettings);
	newrsettings = initialrsettings;
	newrsettings.c_lflag &= ~ECHO;
	if (tcsetattr(fileno(stdin), TCSAFLUSH, &newrsettings) != 0)
	{
		perror("Could not set attributes");
		return -1;
	}

	/* gps power on, and open port */
	if((gps_fd = open(DEVICE_TTYS, O_RDWR)) < 3) {
		perror("Could not open gps device");
		return -1;
	}
	
	/* gps port init */
	tio.c_iflag = IGNBRK | IGNPAR;
	tio.c_cflag = CLOCAL | CREAD | CS8 | HUPCL | CRTSCTS;
	tio.c_oflag = 0;
	tio.c_lflag = 0;
	tio.c_cc[VMIN] = 1;
	tio.c_cc[VTIME] = 10;
	cfsetispeed(&tio, B9600);
	cfsetospeed(&tio, B9600);
	tcsetattr(gps_fd, TCSANOW, &tio);
	
	while(1) {
		memset(gfd_buf, 0, 2048);
		//if (read(gps_fd, gfd_buf, 2048) > 0)
		//	printf("%s", gfd_buf);
		cnt = read(gps_fd, gfd_buf, 2048);
		write(fileno(stdout), gfd_buf, cnt);
		
		/* if read "exit" from stdin, return */
		memset(infd_buf, 0, 128);
		infd_tv.tv_sec = 0;
		infd_tv.tv_usec = 10;
		FD_ZERO(&infds);
		FD_SET(fileno(stdin), &infds);
		D_PRINTF("main select start\n");
		if (!(select(fileno(stdin) + 1, &infds, NULL, NULL, &infd_tv) > 0))
			continue;
		D_PRINTF("main select complete\n");
		if(FD_ISSET(fileno(stdin), &infds))
		{
			read(fileno(stdin), infd_buf, 128);
			if (!strcmp(infd_buf, "exit\n"))
				break;
		}
	}

	tcsetattr(fileno(stdin), TCSANOW, &initialrsettings);

	/* gps power off, and close gps */
	close(gps_fd);

	return 0;
}

