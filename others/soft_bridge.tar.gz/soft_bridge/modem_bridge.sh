#!/system/bin/sh

#kernel printk level
echo 1 > /proc/sys/kernel/printk
#stop rild
stop ril-daemon
#modem_bridge
/data/modem_bridge
#restore printk level
echo 7 > /proc/sys/kernel/printk
#start rild
start ril-daemon

