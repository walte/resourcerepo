#!/system/bin/sh

#kernel printk level
echo 1 > /proc/sys/kernel/printk
#stop rild
stop ril-daemon
sleep 2
#modem_bridge
/data/modem_imsi
#restore printk level
echo 7 > /proc/sys/kernel/printk
#start rild
start ril-daemon

